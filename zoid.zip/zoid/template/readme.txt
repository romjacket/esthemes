Ok, not really  a "template" but you can hide and un-hide the old Genesis theme layer to align the graphics.
The text layer is writable and as close to the original as I could get it.
I size and place the new box art in place, and group them as a new smart object and drop shadow the whole object.

