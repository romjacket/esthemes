# es-theme-ssimplebox
Theme 'ssimplebox' v2
For use with EmulationStation

# Changelog


# License

-------------------------------------------------------------------------
Summary of the license below:<br/>
* ALLOWED:      - Share and duplicate as it is<br/>
              - Edit, alter, change it
* REQUIREMENTS: - Attribution, give credit to the creator<br/>
              - Indicate changes to it<br/>
              - Publish the changes under the same license<br/>
* PROHIBITED:   - Commercial distribution
-------------------------------------------------------------------------
# LOGO NOTICE
* The used logos and trademarks are copyright of their respective owners.
-------------------------------------------------------------------------
