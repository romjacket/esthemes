# simple-dark
simple-dark theme for Emulation Station

Based on:

Theme 'simple' v1.3 - 11-29-2014

(c) Nils Bonenberger - nilsbyte@nilsbyte.de - http://blog.nilsbyte.de/

For use with EmulationStation (http://www.emulationstation.org/)
