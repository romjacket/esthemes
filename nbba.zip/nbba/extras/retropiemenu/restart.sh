sudo reboot
