# Game-Vault-Theme
EmulationStation Theme for Windows with high quality images.

Theme designed by RFleury

Version 1.0

06/03/2018

Originally based on "Simple" by Nils Bonenberger and from this Tutorial:
https://github.com/RetroPie/RetroPie-Setup/wiki/Creating-Your-Own-EmulationStation-Theme

======================================

License

This theme is being actively developed, a great deal of work has been put into the theme.

You are free to modify the theme for your personal use only - please do not share modified versions of this theme.

Commercial distribution is prohibited

======================================



![2018-03-06 1](https://user-images.githubusercontent.com/5437692/37016585-c6f49004-20eb-11e8-90ba-597a67fc9c9e.png)
![2018-03-06 4](https://user-images.githubusercontent.com/5437692/37016586-c716c8c2-20eb-11e8-9eda-cae6c23a6452.png)
![2018-03-06 7](https://user-images.githubusercontent.com/5437692/37016587-c740cf82-20eb-11e8-8897-8b648c448623.png)
![2018-03-06 8](https://user-images.githubusercontent.com/5437692/37016588-c761951e-20eb-11e8-9a5e-059eb450f76f.png)
![2018-03-06](https://user-images.githubusercontent.com/5437692/37016589-c7838bba-20eb-11e8-907b-57346dd580fa.png)



======================================

06/03/2018
Initial release

