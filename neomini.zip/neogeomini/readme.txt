Theme designed by Ruckage
Version 0.6
17/09/2018

Theme based on the menus found on the Japanese version of the Neo Geo Mini.

--------------------------------------------------------------------------------

License

You are free to modify the theme for your personal use only - please do not share modified versions of this theme.

Commercial distribution is prohibited

If in doubt please ask in the dedictated topic at the retropie forum: 

-------------------------------------------------------------------------------  

For the best experience please set 'Transition Style' to 'instant' and 'Carousel Transitions' to 'off'.
This theme relies on grid view support so you will need the very latest version of EmulationStation.  You may need to compile EmulationStation from source which can be done from within Retropie.

You can change the theme style by editing the config.xml file.



17/09/2018 Added several new styles which you can switched between by editing the config.xml file.  New styles are 'classic-red', 'carbon-amber', and 'jazzy'.

26/08/2018 Initial release