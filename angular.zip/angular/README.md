# Angular Theme

Kept you waiting huh?

## Intro

I made this theme for my arcade cabinet, mainly because I got permission to bring it in to school to celebrate the last week. So I wanted to do something special for it.

## The Theme

In case you couldn't tell, this is called the "Angular" theme. Why? The whole motif is the slanted colored bar that acts as the background for the text. 

![](https://i.imgur.com/j1WSxeQ.png)

The System View is the same

![](https://i.imgur.com/MKG2p3W.png)

The image you scrape for your game will fill the background behind everything (screenshots look the best, but you can do whatever you want. In video mode, the marquee will be next to the metadata, and blank if no video. 

If you don't have a video, you can set ES to video mode to show the marquee and the screenshot.

The two color skins for the theme include a dark theme (shown above), and a color theme (below). The colors represent the companies color (Nintendo red, Sega blue, etc.)

![](https://i.imgur.com/mf3rEf3.png)

Github Link: https://github.com/lilbud/es-theme-angular

Will be up on the theme downloader soon


