# es-theme-SpaceOddity
Emulationstation Theme for Retropie - Space Oddity

# Legal Disclaimer:

This project was done on the GNU license. This means that you can distribute and edit your content as long as you refer to the original author in your version. All the art of this project was created by hand by me and is protected by copyright law, which I stipulate through this document which may be freely distributed as long as it is not for any commercial means or included in any product for the same purpose.

# Info:

My second theme, inspired by the moon theme from Nes Duck tales. Hope you enjoy
